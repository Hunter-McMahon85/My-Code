cost = 50
type(cost)
discount = 0.1
type(discount)
discounted_cost = cost-cost*discount
discounted_cost
print(discounted_cost)
discounted_label = "Discounted cost:"
print(discounted_label, discounted_cost)
3+4
5*7
10/2

