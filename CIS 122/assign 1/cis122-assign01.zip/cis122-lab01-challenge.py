'''
CIS 122 Fall 2020 Lab 1 Challenge
Author: Hunter McMahon
Credit: worked on in lab session with GE Luis 
Description: Lab 1 Challenge
'''
#day = Monday           Assign string to a variable
day = "Monday"          # monday needs to be a string, caused runtime error

#square = 2 ^ 2         Perform power operation
square = 2 ** 2        # wrong operator was used prior,semantic error 

#print square          # Output value of a variable
print(square)          # print syntax was wrong, syntax error.

#print(day + square)    Target output is "Monday 4" (without quotation marks)
print(day, square)   # wrong expression, semantic error
